<?php

class Model_Form_UserRegister extends Zend_Form {

    public function init() {

        $this->setName ( 'UserRegister' );
        $this->setAction('/user/register');

        $email = new Model_Form_EText ( 'email', 'Email : ' );
        $email->addValidator ( 'EmailAddress' )->addValidator(new Zend_Validate_Db_NoRecordExists('users','email'));

        $password = new Zend_Form_Element_Password ( 'password' );
        $password->setLabel ( 'Mot de passe : ')->addFilter ( 'StripTags' )->addFilter ( 'StringTrim' )->setRequired ( true );

        $password2 = new Zend_Form_Element_Password ( 'password2' );
        $password2->setLabel ( 'Vérification du mot de passe : ' )->addFilter ( 'StripTags' )->addFilter ( 'StringTrim' );

        $nom = new Model_Form_EText ( 'nom', 'Nom : ' );
        $prenom = new Model_Form_EText ( 'prenom', 'Prénom : ' );
        $adresse = new Model_Form_EText ( 'adresse', 'Adresse : ' );
        $codePostale = new Model_Form_EText ( 'codePostale', 'Code Postale : ' );
        $codePostale->addValidator(new Zend_Validate_Regex('#[0-9]{2} ?[0-9]{3}#'));
        $ville = new Model_Form_EText ( 'ville', 'Ville : ' );
        $telMobile = new Model_Form_EText ( 'telMobile', 'Numéro de téléphone mobile : ' );
        $telMobile->setRequired(false)->addValidator('Digits')->addValidator(new Zend_Validate_StringLength(10));
        $telFixe = new Model_Form_EText ( 'telFixe', 'Numéro de téléphone fixe : ' );
        $telFixe->setRequired(false)->addValidator('Digits')->addValidator(new Zend_Validate_StringLength(10));
        $newsletter = new Zend_Form_Element_Checkbox('newsletter');
        $newsletter->setLabel('En cochant cette case, je m\'abonne à la newsletter');
        $cgv = new Zend_Form_Element_Checkbox('cgv');
        $cgv ->setLabel('En cochant cette case, j\'accepte les CGV')->setRequired(true);
        $submit = new Zend_Form_Element_Submit ( 'submit' );
        $submit->setAttrib ( 'class', 'submitbutton' )->setLabel ( 'Continuer' )->setAttrib('class', 'submit');


        $elements = array ($email, $password, $password2, $nom, $prenom, $adresse,$codePostale,$ville,$telMobile,$telFixe,$newsletter,$cgv ,$submit );
        $this->addElements ( $elements );
    }


    public function isValid($data) {
        $this->getElement('password')->addValidator(new App_Validate_PasswordMatch($data['password2']));
        if ($this->getElement('email')->getValue() == $data['email']) {
            $this->getElement('email')->removeValidator ( "Zend_Validate_Db_NoRecordExists" );
        }
        return parent::isValid($data);
    }

}


class App_Validate_PasswordMatch extends Zend_Validate_Abstract {
    const PASSWORD_MISMATCH = 'passwordMismatch';
    protected $_compare;
    protected $_messageTemplates = array(
            self::PASSWORD_MISMATCH => "PASSWORD_MISMATCH"
    );
    public function __construct($compare) {
        $this->_compare = $compare;
    }
    public function isValid($value) {
        $this->_setValue((string) $value);
        if ($value !== $this->_compare) {
            $this->_error(self::PASSWORD_MISMATCH);
            return false;
        }
        return true;
    }
}





?>
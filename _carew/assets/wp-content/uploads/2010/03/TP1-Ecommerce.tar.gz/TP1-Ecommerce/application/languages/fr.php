<?php
return array(
	
	'Value is required and can\'t be empty'=>'la valeur est requise',
	Zend_Validate_EmailAddress::INVALID=>'l\'adresse email \'%value%\' n\'est pas valide',
	Zend_Validate_EmailAddress::INVALID_FORMAT=>'l\'adresse email \'%value%\' n\'est pas valide',
	Zend_Validate_Int::INVALID=>'la valeur \'%value%\' n\'est pas un nombre',
	Zend_Validate_Int::NOT_INT=>'la valeur \'%value%\' n\'est pas un nombre',
	'PASSWORD_MISMATCH'=>'Les mots de passe ne correpondent pas'
);

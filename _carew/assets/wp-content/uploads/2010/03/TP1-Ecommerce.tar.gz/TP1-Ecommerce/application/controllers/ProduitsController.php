<?php

class ProduitsController extends Zend_Controller_Action {

    public function init() {

    }

    public function indexAction() {
        $produits = new Model_DbTable_Produits();
        $produitsAll = $produits->fetchAll()->toArray();
        $this->view->produitsAll = $produitsAll;

    }



}


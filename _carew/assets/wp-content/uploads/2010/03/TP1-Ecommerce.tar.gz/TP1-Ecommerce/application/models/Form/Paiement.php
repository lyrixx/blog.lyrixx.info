<?php

/**
 * @author lyrix
 *
 */
class Model_Form_Paiement extends Zend_Form {

    public function init() {

        $numCB = new Model_Form_EText('numCB','Numéro de Carte Bancaire : ');
       // $numCB->addValidator('CreditCard');


        $dateExp = new Model_Form_EText('dateExp','Date d\'expiration (MMAAAA) :');
        $dateExp->addValidator('Int')
                ->addValidator(new Zend_Validate_StringLength(6))
                ->addValidator(new MyValidateur_DateCB());

        $crypto = new Model_Form_EText('crpyto','Cryptogramme :');
        $crypto->addValidator('Int')
                ->addValidator(new Zend_Validate_StringLength(3));


        $submit  = new Zend_Form_Element_Submit('submit');
        $submit->setLabel('Valider le Paiment');

        $elements = array($numCB, $dateExp , $crypto, $submit);
        $this->addElements($elements);


    }


}



class MyValidateur_DateCB extends Zend_Validate_Abstract {

    const DATE_EXPIRED = 'dateExpired';

    protected $_messageTemplates = array(
            self::DATE_EXPIRED => "La carte bancaire à expiré."
    );

    public function isValid($value) {
        $this->_setValue($value);

        $dateM = date('m',time());
        $dateY = date('Y',time());

        $ValueM = substr($value, 0,2);
        $ValueY = substr($value, 2,4);


        if ($ValueY < $dateY) {
            $this->_error(self::DATE_EXPIRED);
            return false;
        } elseif ($ValueY == $dateY) {
            if ($ValueM < $dateM) {
                $this->_error(self::DATE_EXPIRED);
                return false;
            }
        }

        return true;
    }


}


?>
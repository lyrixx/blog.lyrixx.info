<?php

class Model_DbTable_Produits extends Zend_Db_Table_Abstract {

    protected $_name = "produits";

    public function fillTable($nbProd = 10) {
        for ($i = 0 ; $i < $nbProd ; $i ++ ) {
            $nom = 'Produit N° '.$i;
            $description = 'Description N° '.$i;
            $prix = rand(0,20);
            $datas = array('nom'=>$nom,'description'=>$description,'prix'=>$prix);
            $this->insert($datas);
        }

    }
    
}

?>
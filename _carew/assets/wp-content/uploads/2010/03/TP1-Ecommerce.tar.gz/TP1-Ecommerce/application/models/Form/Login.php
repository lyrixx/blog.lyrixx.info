<?php

class Model_Form_Login extends Zend_Form {

    public function init() {
        $this->setName('add_user');
        $this->setAction('/user/login');

        $email = new Model_Form_EText('email','Email : ');


        $password = new Zend_Form_Element_Password('password');
        $password->setLabel('Mot de passe : ')
                ->setRequired(true)
                ->addFilter('StripTags')
                ->addFilter('StringTrim');

        $rememberMe = new Zend_Form_Element_Checkbox('rememberMe');
        $rememberMe->setLabel('Se souvenir de Moi : ')
                ->addFilter('StripTags')
                ->addFilter('StringTrim');


        $submit = new Zend_Form_Element_Submit('submit');
        $submit->setLabel('Se connecter')
                ->setAttrib('class', 'submit');

        $elements = array($email,$password, $rememberMe, $submit);
        $this->addElements($elements);

        $this->setDecorators(array(
                'FormElements',
                array('HtmlTag', array('tag' => 'dl', 'class' => 'zend_form')),
                array('Description', array('placement' => 'apend')),
                'Form'
        ));

    }


}

?>

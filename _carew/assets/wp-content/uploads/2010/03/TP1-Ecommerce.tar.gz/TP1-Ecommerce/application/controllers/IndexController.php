<?php

class IndexController extends Zend_Controller_Action {

    public function init() {

    }

    public function indexAction() {
        $this->_helper->redirector('index','produits');
    }

    public function fillprodAction() {
        $prod = new Model_DbTable_Produits();
        $prod->fillTable(50);
        $this->render('index');

    }

}


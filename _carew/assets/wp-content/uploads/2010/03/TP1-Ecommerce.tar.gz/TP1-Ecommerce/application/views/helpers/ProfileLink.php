<?php

class Zend_View_Helper_ProfileLink extends Zend_View_Helper_Abstract {
    public function profileLink() {
        $prefix = '<span class="profileLink">';
        $suffix = '</span>';

        $helperUrl = new Zend_View_Helper_Url ( );
        $auth = Zend_Auth::getInstance ();
        if ($auth->hasIdentity ()) {
            $username = $auth->getIdentity ()->prenom . ' ' .$auth->getIdentity ()->nom;
            $logoutLink = $helperUrl->url ( array ('action' => 'logout', 'controller' => 'user' ) );
            return $prefix.'Bonjour ' . $username . ' (<a href="' . $logoutLink . '">Se deconnecter</a>)'.$suffix ;
        }
        $loginLink = $helperUrl->url ( array ('action' => 'login', 'controller' => 'user' ) );
        $registerLink = $helperUrl->url ( array ('action' => 'register', 'controller' => 'user' ) );
        return $prefix.'<a href="' . $loginLink . '">Se connecter</a> | <a href="' . $registerLink . '">S\'enregister</a>'.$suffix;
    }
}
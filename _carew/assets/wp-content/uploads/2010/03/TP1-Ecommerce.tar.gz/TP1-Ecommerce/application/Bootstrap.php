<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	public function run() {
		// Cela permet d'avoir le fichier de configuration disponible depuis n'importe ou dans l'application. 
		Zend_Registry::set ( 'config', new Zend_Config ( $this->getOptions () ) );
		parent::run ();
	}
	
	/**
	 * Initialize Module
	 * 
	 * @return Zend_Application_Module_Autoloader
	 */
	protected function _initAutoload() {
		$loader = new Zend_Application_Module_Autoloader ( array ('namespace' => '', 'basePath' => APPLICATION_PATH ) );
		return $loader;
	}
	
	/**
	 * Initialize session
	 * 
	 * @return Zend_Session_Namespace
	 */
	protected function _initSession() {
		// On initialise la session
		$session = new Zend_Session_Namespace ( 'ecommerce', true );
		Zend_Registry::set('session',$session);
		return $session;
	}
	
	/**
	 * Initialize View
	 * 
	 * @return Zend_View
	 */
	protected function _initView() {
		// Initialize view
		$view = new Zend_View ( );
		$view->doctype ( 'XHTML1_STRICT' );
		$view->headMeta ()->appendHttpEquiv ( 'Content-Type', 'text/html; charset=UTF-8' );
		// Add it to the ViewRenderer
		$viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper ( 'ViewRenderer' );
		$viewRenderer->setView ( $view );
		// Return it, so that it can be stored by the bootstrap
		return $view;
	}
	
	/**
	 * Initialize Translation
	 *
	 * @return Zend_Translate
	 */
	public function _initTranslate() {
		$translate = new Zend_Translate ( 'array', APPLICATION_PATH . '/languages/fr.php', 'fr' );
		Zend_Registry::set ( 'Zend_Translate', $translate );
		return $translate;
	}

}


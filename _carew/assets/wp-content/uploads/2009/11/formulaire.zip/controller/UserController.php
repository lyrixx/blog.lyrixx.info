<?php

class UserController extends Zend_Controller_Action {
	
	public function init() {
		/* Initialize action controller here */
		$activeNav = $this->view->navigation ()->findByController ( 'user' );
		$activeNav->active = true;
		$activeNav->setClass ( "active" );
	}
	
	public function indexAction() {
		if ($this->getRequest ()->getParam ( 'act' ) == 'update') {
			$this->view->msg = "form_user_update_done";
		} else if ($this->getRequest ()->getParam ( 'act' ) == 'delete') {
			$this->view->msg = "form_user_delete_done";
		} else if ($this->getRequest ()->getParam ( 'act' ) == 'error') {
			$this->view->msg = "form_user_error";
		}
		$form = new Model_Form_User_User ( );
		$this->view->formUser = $form;
		if ($this->_request->isPost ()) {
			$formData = $this->_request->getPost ();
			if ($form->isValid ( $formData )) {
				$users = new Model_DbTable_Users ( );
				$row = $users->createRow ();
				$row->nom = $form->getValue ( 'nom' );
				$row->prenom = $form->getValue ( 'prenom' );
				$row->email = $form->getValue ( 'email' );
				$row->password = md5 ( $form->getValue ( 'password' ) );
				$row->active = $form->getValue ( 'active' );
				$row->level = $form->getValue ( 'level' );
				$result = $row->save ();
				$this->view->msg = "form_user_add_done";
				$form->reset ();
			}
		}
		$this->view->usersAll = $this->getUsersAll ();
	}
	
	public function editAction() {
		try {
			$form = new Model_Form_User_User ( );
			$form->setIdUser ( $this->getRequest ()->getParam ( 'id' ) );
			$form->init ();
			$this->view->formUserEdit = $form;
		} catch ( Zend_Exception $e ) {
			$this->view->msg = $e->getMessage ();
		}
		if ($this->_request->isPost ()) {
			$formData = $this->_request->getPost ();
			if ($form->isValid ( $formData )) {
				$user = new Model_DbTable_Users ( );
				if ($formData ['password'] == "") {
					unset ( $formData ['password'] );
					unset ( $formData ['password2'] );
				} else {
					$formData ['password'] = md5 ( $formData ['password'] );
					unset ( $formData ['password2'] );
				}
				unset ( $formData ['submit'] );
				$result = $user->update ( $formData, array ("idUser = ?" => $formData ['idUser'] ) );
				if ($result) {
					$this->_helper->redirector ( 'index', 'user', '', array ('act' => 'update' ) );
				}else{
					$this->_helper->redirector ( 'index', 'user', '', array ('act' => 'error' ) );
				}
			}
		}
		$this->view->usersAll = $this->getUsersAll ();
		$this->render ( "index" );
	}
	
	public function delAction() {
		$id = $this->getRequest ()->getParam ( 'id' );
		$this->view->delUserId = $id;
		$this->view->usersAll = $this->getUsersAll ();
		$this->render ( 'index' );
	}
	
	public function deleteAction() {
		$id = $this->getRequest ()->getParam ( 'id' );
		$user = new Model_DbTable_Users ( );
		$result = $user->delete ( array ("idUser = ?" => $id ) );
		if ($result) {
			$this->_helper->redirector ( 'index', 'user', '', array ('act' => 'delete' ) );
		}else{
			$this->_helper->redirector ( 'index', 'user', '', array ('act' => 'error' ) );
		}
	}
	
	private function getUsersAll() {
		$dbUser = new Model_DbTable_Users ( );
		return $dbUser->fetchAll ()->toArray ();
	}

}


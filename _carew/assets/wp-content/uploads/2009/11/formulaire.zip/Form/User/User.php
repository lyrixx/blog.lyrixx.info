<?php

class Model_Form_User_User extends Zend_Form {
	
	private $idUser;
	private $controllerAction;
	
	public function init() {
		$this->setName ( 'add_user' );
		
		$id = new Zend_Form_Element_Hidden ( 'idUser' );
		
		$nom = new Model_Form_EText ( 'nom', 'form_user_add_name' );
		
		$prenom = new Model_Form_EText ( 'prenom', 'form_user_add_firstname' );
		
		$email = new Model_Form_EText ( 'email', 'form_user_add_mail' );
		$email->addValidator ( 'EmailAddress' )->addValidator ( new Zend_Validate_Db_NoRecordExists ( 'users', 'email' ) );
		
		$password = new Zend_Form_Element_Password ( 'password' );
		$password->setLabel ( 'form_user_add_password' )->addFilter ( 'StripTags' )->addFilter ( 'StringTrim' )->setRequired ( true );
		
		$password2 = new Zend_Form_Element_Password ( 'password2' );
		$password2->setLabel ( 'form_user_add_password2' )->addFilter ( 'StripTags' )->addFilter ( 'StringTrim' );
		
		$active = new Zend_Form_Element_Checkbox ( 'active' );
		$active->setLabel ( 'form_user_add_enable' )->addFilter ( 'StripTags' )->addFilter ( 'StringTrim' )->setValue ( 1 );
		
		$level = new Zend_Form_Element_Select ( 'level' );
		$level->setLabel ( 'form_user_add_level' )->addFilter ( 'StripTags' )->addFilter ( 'StringTrim' );
		$levelOptions = array ();
		for($i = 0; $i <= 9; $i ++) {
			$levelOptions [$i] = array ('key' => $i, 'value' => $i );
		}
		$level->addMultiOptions ( $levelOptions );
		
		$submit = new Zend_Form_Element_Submit ( 'submit' );
		$submit->setAttrib ( 'id', 'submitbutton' )->setLabel ( 'form_user_add_submit' );
		
		$elements = array ($id, $nom, $prenom, $email, $password, $password2, $active, $level, $submit );
		$this->addElements ( $elements );
		
		$idUser = $this->getIdUser();
		if (isset ( $idUser ) && $idUser != "") {
			$user = new Model_DbTable_Users ( );
			$user = $user->fetchRow ( array ("idUser = ?" => $idUser ) );
			if ($user != null) {
				$user = $user->toArray ();
				$this->populate ( $user );
			} else {
				throw new Zend_Exception ( "form_user_no_id" );
			}
			$password->setDescription ( "form_user_update_password_change" );
			$password->setRequired ( false );
			$submit->setLabel ( 'form_user_update_submit' );
		}
	}
	
	public function isValid($data) {
		$this->getElement ( 'password' )->addValidator ( new App_Validate_PasswordMatch ( $data ['password2'] ) );
		if ($this->getElement ( 'email' )->getValue () == $data ['email']) {
			$this->getElement ( 'email' )->removeValidator ( "Zend_Validate_Db_NoRecordExists" );
		}
		return parent::isValid ( $data );
	}
	
	
	/**
	 * @param $idUser the $idUser to set
	 */
	public function setIdUser($idUser) {
		$this->idUser = $idUser;
	}

	/**
	 * @return the $idUser
	 */
	public function getIdUser() {
		return $this->idUser;
	}

}

class App_Validate_PasswordMatch extends Zend_Validate_Abstract {
	const PASSWORD_MISMATCH = 'passwordMismatch';
	protected $_compare;
	protected $_messageTemplates = array (self::PASSWORD_MISMATCH => "PASSWORD_MISMATCH" );
	public function __construct($compare) {
		$this->_compare = $compare;
	}
	public function isValid($value) {
		$this->_setValue ( ( string ) $value );
		if ($value !== $this->_compare) {
			$this->_error ( self::PASSWORD_MISMATCH );
			return false;
		}
		return true;
	}
}

?>
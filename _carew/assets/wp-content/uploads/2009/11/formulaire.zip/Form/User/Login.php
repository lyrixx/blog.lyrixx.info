<?php

class Model_Form_User_Login extends Zend_Form  {
	
	public function init(){
		$this->setName('add_user');
		
		$email = new Model_Form_EText('email','form_user_add_mail');

        $password = new Zend_Form_Element_Password('password');
        $password->setLabel('form_user_add_password')
        	->setRequired(true)
            ->addFilter('StripTags')
            ->addFilter('StringTrim');
        
        $redirect = new Zend_Form_Element_Hidden('_redirect_url');
        $redirect->getDecorator('HtmlTag')->setOption('class', 'hidden');
        $redirect->removeDecorator('Label');
            
            
        $submit = new Zend_Form_Element_Submit('submit');
        $submit->setAttrib('id', 'submitbutton')
               ->setLabel('form_user_login_submit');
		
		$elements = array($email,$password,$redirect, $submit);
        $this->addElements($elements);
        
        $this->setDecorators(array(
            'FormElements',
            array('HtmlTag', array('tag' => 'dl', 'class' => 'zend_form')),
            array('Description', array('placement' => 'apend')),
            'Form'
        ));
		
	}
	
	
    public function setRedirectUrl($url){
		$this->getElement('_redirect_url')->setValue($url);
	}

	public function getRedirectUrl(){
		return $this->getElement('_redirect_url')->getValue();
	}
	
	
}

?>